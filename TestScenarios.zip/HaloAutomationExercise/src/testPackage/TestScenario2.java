package testPackage;

/*
Scenario 2 : Search Functionality in Flipkart Application.

* Search Functionality is also important because it is almost used in many web Application.
* I used Selenium WebDriver and TestNG Configuration for this Scenario.
* @BeforeMethod allows the method to execute before the execution of each @Test methods, whereas @afterMethod is executed after the execution of each @Test methods
*/

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestScenario2 {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
    	// Set path to ChromeDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\pintu\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.flipkart.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Test
    public void searchProductTest() {
       
        WebElement searchBox = driver.findElement(By.name("q"));
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        searchBox.sendKeys("laptop");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        searchBox.submit();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        // Wait for search results and select any product
        WebElement anyProduct = driver.findElement(By.partialLinkText("Apple MacBook AIR Apple M2"));
        anyProduct.click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @AfterMethod
    public void closeApp() {
        driver.quit();
    }
}
