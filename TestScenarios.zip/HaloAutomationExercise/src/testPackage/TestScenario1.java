package testPackage;

/*
Scenario 1 : User Login Functionality in FaceBook Application.

* User Login Functionality is important because it is used in almost all web Application.
* I used Selenium WebDriver and TestNG Configuration for this Scenario.
* @BeforeMethod allows the method to execute before the execution of each @Test methods, whereas @afterMethod is executed after the execution of each @Test methods
*/

import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestScenario1 {
    WebDriver driver;

    @BeforeMethod
    public void openApp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\pintu\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.facebook.com/login.php/");
        driver.manage().window().maximize();
    }

    @Test
    public void testLogin() {
        driver.findElement(By.id("email")).sendKeys("TestUser1");
        driver.findElement(By.id("pass")).sendKeys("User@01");
        driver.findElement(By.id("loginbutton")).click();
    }

    @AfterMethod
    public void closeApp() {
        driver.quit();
    }
}
